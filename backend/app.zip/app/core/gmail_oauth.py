"""
ThreatShield AI - Per-User Gmail OAuth (Web Application flow)

This is the NEW per-user OAuth flow: each ThreatShield user connects their
own Gmail account via a browser redirect to Google's consent screen.

This is intentionally separate from app/core/gmail_auth.py, which implements
the OLD single shared-mailbox flow using InstalledAppFlow.run_local_server()
(a "Desktop app" OAuth client that pops a local browser on the SERVER).
That flow cannot be reused here — a Desktop app OAuth client and a Web
application OAuth client are different client types in Google Cloud Console,
with different security models. Web flows need a registered redirect URI
and exchange an authorization code via HTTP, never opening a browser
themselves.

Setup required in Google Cloud Console (one-time, by whoever owns the
project):
  1. APIs & Services -> Credentials -> Create Credentials -> OAuth client ID
  2. Application type: "Web application" (NOT "Desktop app")
  3. Authorized redirect URIs: add the exact value of GMAIL_OAUTH_REDIRECT_URI
     from .env, e.g. http://localhost:8000/api/gmail/oauth/callback
  4. Copy the Client ID and Client Secret into .env as GMAIL_OAUTH_CLIENT_ID /
     GMAIL_OAUTH_CLIENT_SECRET
  5. While the app is in "Testing" publishing status, every Gmail account
     that will connect must be added under OAuth consent screen -> Audience
     -> Test users (capped at 100 test users). Going to "In production" for
     unlimited public users requires Google's verification review for
     sensitive Gmail scopes.
"""
import logging
from datetime import datetime, timezone
from typing import Optional

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request as GoogleAuthRequest
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

from app.core.config import settings

logger = logging.getLogger(__name__)

# Scopes requested from the user. Kept identical to the legacy flow so
# downstream scanning/labeling code works unchanged regardless of which
# flow connected the account.
GMAIL_OAUTH_SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.send",
]


def _client_config() -> dict:
    """Build the Google 'client secrets' config dict from app settings."""
    return {
        "web": {
            "client_id": settings.GMAIL_OAUTH_CLIENT_ID,
            "client_secret": settings.GMAIL_OAUTH_CLIENT_SECRET,
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "redirect_uris": [settings.GMAIL_OAUTH_REDIRECT_URI],
        }
    }


def is_configured() -> bool:
    """True if the web OAuth client credentials have been set in .env."""
    return bool(settings.GMAIL_OAUTH_CLIENT_ID and settings.GMAIL_OAUTH_CLIENT_SECRET)


def build_authorization_url(state: str) -> str:
    """
    Build the Google consent screen URL the user's browser should be
    redirected to. `state` should be a signed token from
    security.create_oauth_state_token() so the callback can verify it later.
    """
    if not is_configured():
        raise RuntimeError(
            "Gmail OAuth is not configured. Set GMAIL_OAUTH_CLIENT_ID and "
            "GMAIL_OAUTH_CLIENT_SECRET in .env (see app/core/gmail_oauth.py "
            "module docstring for setup steps)."
        )

    flow = Flow.from_client_config(
        _client_config(),
        scopes=GMAIL_OAUTH_SCOPES,
        redirect_uri=settings.GMAIL_OAUTH_REDIRECT_URI,
    )
    authorization_url, _ = flow.authorization_url(
        access_type="offline",       # required to receive a refresh_token
        include_granted_scopes="true",
        prompt="consent",            # force refresh_token even on re-connect
        state=state,
    )
    return authorization_url


def exchange_code_for_credentials(authorization_code: str) -> Credentials:
    """
    Exchange the one-time authorization code Google sent to our callback
    for real OAuth credentials (access token + refresh token).
    """
    flow = Flow.from_client_config(
        _client_config(),
        scopes=GMAIL_OAUTH_SCOPES,
        redirect_uri=settings.GMAIL_OAUTH_REDIRECT_URI,
    )
    flow.fetch_token(code=authorization_code)
    return flow.credentials


def get_gmail_address(creds: Credentials) -> str:
    """Call Gmail's getProfile to find out which mailbox we just connected."""
    service = build("gmail", "v1", credentials=creds)
    profile = service.users().getProfile(userId="me").execute()
    return profile.get("emailAddress", "")


def credentials_from_stored_tokens(
    access_token: Optional[str],
    refresh_token: str,
    expiry: Optional[datetime],
) -> Credentials:
    """Reconstruct a Credentials object from values pulled out of the DB."""
    creds = Credentials(
        token=access_token,
        refresh_token=refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=settings.GMAIL_OAUTH_CLIENT_ID,
        client_secret=settings.GMAIL_OAUTH_CLIENT_SECRET,
        scopes=GMAIL_OAUTH_SCOPES,
    )
    if expiry:
        creds.expiry = expiry.astimezone(timezone.utc).replace(tzinfo=None)
    return creds


def refresh_if_needed(creds: Credentials) -> Credentials:
    """Refresh the access token in-place if it's expired. Mutates and returns creds."""
    if not creds.valid and creds.refresh_token:
        creds.refresh(GoogleAuthRequest())
    return creds


def build_gmail_service(creds: Credentials):
    """Build an authenticated Gmail API client for this user's connected account."""
    return build("gmail", "v1", credentials=creds)