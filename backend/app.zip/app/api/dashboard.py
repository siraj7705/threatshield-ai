"""
ThreatShield AI - Dashboard & Analytics API Routes
"""
import json
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc, case

from app.core.database import get_db
from app.core.security import get_current_user, is_admin
from app.models.email import Email
from app.models.threat import ThreatAnalysis, ThreatScore
from app.models.alert import Alert
from app.models.case import Case
from app.schemas import DashboardStats, DashboardResponse, AlertResponse, ThreatTrend

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/stats", response_model=DashboardResponse)
async def get_dashboard_stats(
    days: int = Query(30, ge=1, le=365),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Get comprehensive dashboard statistics.

    Admins see organization-wide numbers across every user's data — that's
    intentional for a SOC admin role. Analysts/investigators see numbers
    scoped to their own emails (uploaded or scanned from their own
    connected Gmail account) plus anything from the shared mailbox watcher,
    consistent with how /api/emails, /api/cases, /api/alerts, and
    /api/threats are scoped.
    """
    admin_view = is_admin(current_user)
    user_id = current_user["id"]

    def email_owned():
        return (Email.source_type == "gmail_watch") | (Email.uploaded_by == user_id)

    def case_owned():
        return (Case.created_by == user_id) | (Case.assigned_to == user_id)

    def alert_owned_join(query):
        # LEFT OUTER JOIN so alerts with no linked email still count
        # (they have no single owner) — same rule as in alerts.py.
        return query.outerjoin(Email, Alert.email_id == Email.id).where(
            (Alert.email_id.is_(None)) | email_owned()
        )

    # Total emails
    total_q = select(func.count(Email.id))
    if not admin_view:
        total_q = total_q.where(email_owned())
    total_emails = (await db.execute(total_q)).scalar() or 0

    # Threat emails (joined through Email for ownership scoping)
    threat_q = select(func.count(ThreatAnalysis.id)).where(ThreatAnalysis.threat_detected == True)
    if not admin_view:
        threat_q = threat_q.join(Email, ThreatAnalysis.email_id == Email.id).where(email_owned())
    threat_emails = (await db.execute(threat_q)).scalar() or 0

    # Safe emails
    safe_emails = total_emails - threat_emails

    # Blocked emails
    blocked_q = select(func.count(Email.id)).where(Email.action_taken == "block")
    if not admin_view:
        blocked_q = blocked_q.where(email_owned())
    blocked_emails = (await db.execute(blocked_q)).scalar() or 0

    # Quarantined emails
    quarantined_q = select(func.count(Email.id)).where(Email.action_taken == "quarantine")
    if not admin_view:
        quarantined_q = quarantined_q.where(email_owned())
    quarantined_emails = (await db.execute(quarantined_q)).scalar() or 0

    # Pending emails
    pending_q = select(func.count(Email.id)).where(Email.status == "pending")
    if not admin_view:
        pending_q = pending_q.where(email_owned())
    pending_emails = (await db.execute(pending_q)).scalar() or 0

    # Critical alerts
    critical_q = select(func.count(Alert.id)).where(Alert.severity == "critical")
    if not admin_view:
        critical_q = critical_q.select_from(Alert)
        critical_q = alert_owned_join(critical_q)
    critical_alerts = (await db.execute(critical_q)).scalar() or 0

    # Unacknowledged alerts
    unack_q = select(func.count(Alert.id)).where(Alert.is_acknowledged == False)
    if not admin_view:
        unack_q = unack_q.select_from(Alert)
        unack_q = alert_owned_join(unack_q)
    unacknowledged_alerts = (await db.execute(unack_q)).scalar() or 0

    # Active cases
    cases_q = select(func.count(Case.id)).where(Case.status.in_(["open", "in_progress"]))
    if not admin_view:
        cases_q = cases_q.where(case_owned())
    active_cases = (await db.execute(cases_q)).scalar() or 0

    stats = DashboardStats(
        total_emails=total_emails,
        threat_emails=threat_emails,
        safe_emails=safe_emails,
        blocked_emails=blocked_emails,
        quarantined_emails=quarantined_emails,
        pending_emails=pending_emails,
        critical_alerts=critical_alerts,
        unacknowledged_alerts=unacknowledged_alerts,
        active_cases=active_cases,
    )

    # Recent alerts
    alerts_q = select(Alert).order_by(desc(Alert.created_at)).limit(10)
    if not admin_view:
        alerts_q = alert_owned_join(alerts_q)
    alerts_result = await db.execute(alerts_q)
    recent_alerts = [AlertResponse.model_validate(a) for a in alerts_result.scalars().all()]

    # Severity distribution
    severity_q = select(ThreatScore.category, func.count(ThreatScore.id))
    if not admin_view:
        severity_q = severity_q.join(Email, ThreatScore.email_id == Email.id).where(email_owned())
    severity_q = severity_q.group_by(ThreatScore.category)
    severity_query = await db.execute(severity_q)
    severity_distribution = dict(severity_query.all())

    # Top threat types
    type_q = select(ThreatAnalysis.threat_type, func.count(ThreatAnalysis.id)).where(
        ThreatAnalysis.threat_detected == True
    )
    if not admin_view:
        type_q = type_q.join(Email, ThreatAnalysis.email_id == Email.id).where(email_owned())
    type_q = type_q.group_by(ThreatAnalysis.threat_type).order_by(desc(func.count(ThreatAnalysis.id))).limit(10)
    type_query = await db.execute(type_q)
    top_threat_types = dict(type_query.all())

    # Threat trends (simplified - count per day)
    threat_trends = []

    return DashboardResponse(
        stats=stats,
        recent_alerts=recent_alerts,
        threat_trends=threat_trends,
        severity_distribution=severity_distribution,
        top_threat_types=top_threat_types,
    )